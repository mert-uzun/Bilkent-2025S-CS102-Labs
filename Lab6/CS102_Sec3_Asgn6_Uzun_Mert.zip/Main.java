package Lab6;

public class Main {
    public static void main(String[] args) {
        BankSimulation bankSimulation = new BankSimulation();
        bankSimulation.startSimulation();
    }
}
